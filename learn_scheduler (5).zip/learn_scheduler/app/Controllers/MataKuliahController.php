<?php

namespace App\Controllers;

use App\Models\MatkulModel;
use CodeIgniter\Controller;
use Exception;

class MataKuliahController extends Controller
{
    public function index()
    {
        $MatkulModel = new MatkulModel();
        $data = [
            'judul' => 'Mata Kuliah',
            'all_data' => $MatkulModel->findAll()
        ];

        return view('/MataKuliah/index', $data);
    }

    public function simpan()
    {

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $time = date("His");
            $id = intval($time);
            $namaMatkul = $_POST['namaMatkul'];
            $semester = $_POST['semester'];

            // Catch file upload
            $target_dir = './assets/img/upload/';
            $target_file = $target_dir . basename($_FILES["fileBackground"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            // Cek file sudah ada atau tidak
            if (file_exists($target_file)) {
                unlink($target_file);
            }

            //Cek extensi file yang diperbolehkan
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
                $uploadOk = 0;
            }

            // Batasi ukuran file (maksimal 5MB)
            if ($_FILES["fileBackground"]["size"] > 5000000) {
                $uploadOk = 0;
            }

            // Periksa apakah $uploadOk bernilai 0 karena error
            if ($uploadOk == 0) {
                $status = 'gagal';
            } else {
                if (move_uploaded_file($_FILES["fileBackground"]["tmp_name"], $target_file)) {
                    $status = "berhasil";
                } else {
                    $status = "gagal";
                }
            }

            $data = [
                'id' => $id,
                'nama_matakuliah' => $namaMatkul,
                'semester' => $semester,
                'background' => $target_file,
                'status' => $status
            ];

            $MatkulModel = new MatkulModel();
            try {
                $MatkulModel->insert($data);
                session()->setFlashdata('message', 'berhasil');
                $message = 'berhasil';
            } catch (Exception $e) {
                session()->setFlashdata('message', 'gagal');
                $message = 'gagal';
            }
            // Set flashdata sebagai pesan untuk halaman berikutnya
            return redirect()->to(base_url('/mata-kuliah'));
        }
    }
    public function update($id)
    {
        $MatkulModel = new MatkulModel();
        $namaMatkul = $_POST['namaMatkul'];
        $semester = $_POST['semester'];
        // Catch file upload
        $target_dir = './assets/img/upload/';
        $target_file = $target_dir . basename($_FILES["fileBackground"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        // Cek file sudah ada atau tidak
        if (file_exists($target_file)) {
            unlink($target_file);
        }

        //Cek extensi file yang diperbolehkan
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            $uploadOk = 0;
        }

        // Batasi ukuran file (maksimal 5MB)
        if ($_FILES["fileBackground"]["size"] > 5000000) {
            $uploadOk = 0;
        }

        // Periksa apakah $uploadOk bernilai 0 karena error
        if ($uploadOk == 0) {
            $status = 'gagal';
        } else {
            if (move_uploaded_file($_FILES["fileBackground"]["tmp_name"], $target_file)) {
                $status = "berhasil";
            } else {
                $status = "gagal";
            }
        }

        $data = [
            'nama_matakuliah' => $namaMatkul,
            'semester'    => $semester,
            'background' =>  $target_file,
        ];

        if ($MatkulModel->update($id, $data)) {
            session()->setFlashdata('message', 'berhasil');
        } else {
            session()->setFlashdata('message', 'gagal');
        }

        return redirect()->to(base_url("/mata-kuliah"));
    }

    public function delete($id)
    {
        $MatkulModel = new MatkulModel();
        if ($MatkulModel->delete($id)) {
            session()->setFlashdata('message', 'berhasil');
        } else {
            session()->setFlashdata('message', 'gagal');
        }

        return redirect()->to(base_url("/mata-kuliah"));
    }
}

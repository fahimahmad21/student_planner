<?php

namespace App\Controllers;

use CodeIgniter\Controller;

use Assets\Ollama;

class WebUIIntegration extends Controller
{
    private $ollama;

    public function __construct()
    {
        $this->ollama = new Ollama();
    }

    public function index()
    {
        // Now you can use $this->ollama to access Ollama's methods
        $response = $this->ollama->generate($data);
        // ...
    }
}
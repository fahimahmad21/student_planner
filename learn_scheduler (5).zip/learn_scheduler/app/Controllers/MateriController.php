<?php

namespace App\Controllers;

use App\Models\MateriModel;
use App\Models\MatkulModel;
use CodeIgniter\Controller;

class MateriController extends Controller
{
    public function materi($id)
    {
        $MateriModel = new MateriModel();
        $MatkulModel = new MatkulModel();

        $matkul = $MatkulModel->find($id);
        $namaMatkul = $matkul['nama_matakuliah'];
        $materi = $MateriModel->where('matkul', $namaMatkul)->findAll();
        // dd($materi);
        $data = [
            'judul' => 'Materi',
            'materi' => $materi,
            'namaMatkul' => $namaMatkul
        ];
        return view('/MataKuliah/materi', $data);
    }

    public function simpan($namaMatkul)
    {
        $MateriModel = new MateriModel();
        $MatkulModel = new MatkulModel();
        $matkul = $MatkulModel->where('nama_matakuliah', $namaMatkul)->findAll();
        $idMatkul = $matkul[0]['id'];
        $time = date("His");
        $id = intval($time);
        $judul = $_POST['judul'];

        // Catch file upload
        $target_dir = './assets/file/';
        $target_file = $target_dir . basename($_FILES["materiFile"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        // Cek file sudah ada atau tidak
        if (file_exists($target_file)) {
            unlink($target_file);
        }

        //Cek extensi file yang diperbolehkan
        if ($imageFileType != "pdf" && $imageFileType != "xlxs" && $imageFileType != "docx") {
            $uploadOk = 0;
        }

        // Batasi ukuran file (maksimal 5MB)
        if ($_FILES["materiFile"]["size"] > 5000000) {
            $uploadOk = 0;
        }

        // Periksa apakah $uploadOk bernilai 0 karena error
        if ($uploadOk == 0) {
            $status = 'gagal';
        } else {
            if (move_uploaded_file($_FILES["materiFile"]["tmp_name"], $target_file)) {
                $status = "berhasil";
            } else {
                $status = "gagal";
            }
        }

        $data = [
            'id' => $id,
            'judul' => $judul,
            'file' => $target_file,
            'matkul' => $namaMatkul
        ];

        if (!$MateriModel->insert($data)) {
            session()->setFlashdata('message', 'berhasil');
        } else {
            session()->setFlashdata('message', 'gagal');
        }

        return redirect()->to(base_url('/materi/' . $idMatkul));
    }

    public function hapus($id)
    {
        $MateriModel = new MateriModel();
        $MatkulModel = new MatkulModel();
        $materi = $MateriModel->where('id', $id)->findAll();
        $namaMatkul = $materi[0]['matkul'];
        $matkul = $MatkulModel->where('nama_matakuliah', $namaMatkul)->findAll();
        $idMatkul = $matkul[0]['id'];
        if ($MateriModel->delete($id)) {
            session()->setFlashdata('message', 'berhasil');
        } else {
            session()->setFlashdata('message', 'gagal');
        }

        return redirect()->to(base_url('/materi/' . $idMatkul));
    }

    public function edit($id)
    {
        $MateriModel = new MateriModel();
        $MatkulModel = new MatkulModel();
        $materi = $MateriModel->where('id', $id)->findAll();
        $namaMatkul = $materi[0]['matkul'];
        $matkul = $MatkulModel->where('nama_matakuliah', $namaMatkul)->findAll();
        $idMatkul = $matkul[0]['id'];



        $judul = $_POST['judul'];
        // Catch file upload
        $target_dir = './assets/file/';
        $target_file = $target_dir . basename($_FILES["materiFile"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        // Cek file sudah ada atau tidak
        if (file_exists($target_file)) {
            unlink($target_file);
        }

        //Cek extensi file yang diperbolehkan
        if ($imageFileType != "pdf" && $imageFileType != "xlxs" && $imageFileType != "docx") {
            $uploadOk = 0;
        }

        // Batasi ukuran file (maksimal 5MB)
        if ($_FILES["materiFile"]["size"] > 5000000) {
            $uploadOk = 0;
        }

        // Periksa apakah $uploadOk bernilai 0 karena error
        if ($uploadOk == 0) {
            $status = 'gagal';
        } else {
            if (move_uploaded_file($_FILES["materiFile"]["tmp_name"], $target_file)) {
                $status = "berhasil";
            } else {
                $status = "gagal";
            }
        }

        $data = [
            'judul' => $judul,
            'file' => $target_file,
            'matkul' => $namaMatkul
        ];

        if ($MateriModel->update($id, $data)) {
            session()->setFlashdata('message', 'berhasil');
        } else {
            session()->setFlashdata('message', 'gagal');
        }

        return redirect()->to(base_url('/materi/' . $idMatkul));
    }
}

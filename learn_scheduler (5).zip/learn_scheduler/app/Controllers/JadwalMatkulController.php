<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\JadwalKuliahModel;

class JadwalMatkulController extends BaseController
{
    public function index()
    {
        $data = [
            'judul' => 'Jadwal Kuliah'
        ];
        return view('/JadwalMatkul/index', $data);
    }

    public function simpan()
    {
        $JadwalKuliah = new JadwalKuliahModel();
        $time = date("His");
        $id = intval($time);
        $hari = $_POST['hari'];
        $jamMulai = $_POST['jamMulai'];
        $jamBerakhir = $_POST['jamBerakhir'];
        $matakuliah = $_POST['mataKuliah'];
        $ruangan = $_POST['ruangan'];

        $data = [
            'id' => $id,
            'hari' => $hari,
            'jam1' => $jamMulai,
            'jam2' => $jamBerakhir,
            'matkul' => $matakuliah,
            'ruangan' => $ruangan
        ];

        if ($JadwalKuliah->insert($data)) {
            session()->getFlashdata('message', 'berhasil');
        } else {
            session()->getFlashdata('message', 'gagal');
        }

        return redirect()->to(base_url('/jadwal-kuliah'));
    }
}

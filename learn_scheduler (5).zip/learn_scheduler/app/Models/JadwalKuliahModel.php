<?php

namespace App\Models;

use CodeIgniter\Model;

class JadwalKuliahModel extends Model
{
    protected $table            = 'jadwalkuliah';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $allowedFields    = ['id', 'hari', 'jam1', 'jam2', 'matkul', 'ruangan'];
}

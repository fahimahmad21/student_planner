<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->get('/mata-kuliah', 'MataKuliahController::index');
$routes->post('/mata-kuliah/simpan', 'MataKuliahController::simpan');
$routes->post('/mata-kuliah/update/(:any)', 'MataKuliahController::update/$1');
$routes->post('/mata-kuliah/delete/(:any)', 'MataKuliahController::delete/$1');

$routes->post('/materi/save/(:any)', 'MateriController::simpan/$1');
$routes->get('/materi/(:any)', 'MateriController::materi/$1');
$routes->post('/materi/hapus/(:any)', 'MateriController::hapus/$1');
$routes->post('/materi/edit/(:any)', 'MateriController::edit/$1');

$routes->get('/jadwal-kuliah', 'JadwalMatkulController::index');

// Tambahkan route untuk WebUIIntegration Controller

$routes->post('/webui/send-data', 'WebUIIntegration::sendData');   // Route untuk mengirim data
$routes->add('ollama', 'OllamaController::index'); // Contoh

$routes->get('webui', 'WebUIIntegration::index');
$routes->get('test-endpoint/(:any)', 'WebUIIntegration::testEndpoint/$1');

<?= $this->extend('/layout/all') ?>

<?= $this->section('content') ?>
<div class="container-fluid">

    <?php
    $message = session()->getFlashdata('message');
    if (!empty($message)) {
        if ($message == 'berhasil') {
    ?>
            <div class="alert alert-success" role="alert">
                Mata Kuliah berhasil dihapus!
            </div>
        <?php
        } else if ($message == 'gagal') {
        ?>
            <div class="alert alert-danger" role="alert">
                Gagal menghapus Mata Kuliah. Mata Kuliah ini sedang digunakan di tabel lain!
            </div>
    <?php
        }
    }
    ?>

    <!-- Page Heading -->
    <div class="heading d-flex">
        <h1 class="h3 mb-4 text-gray-800" style="font-size: 35px; font-weight: 600;"><?= $judul; ?></h1>
        <div class="tambah-data" style="margin-left:74%;">
            <button type="button" data-bs-toggle="modal" data-bs-target="#tambahMatkul" class="btn btn-secondary" style="border-radius: 50%;"><i class="fas fa-plus"></i></button>
        </div>
    </div>

    <style>
        .card.mata-kuliah {
            width: 29%;
            margin: 5px;
            height: 320px;
        }

        .matkul-card.action {
            margin: 3px;
        }

        .title.mata-kuliah {
            margin: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            font-weight: 700;
            font-size: 20px;
        }

        .card {
            box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
        }
    </style>

    <div class="content">
        <div class="d-flex flex-wrap">
            <?php
            foreach ($all_data as $a) {
            ?>
                <style>
                    .matkul-image {
                        border-radius: 5px;
                        background-size: cover;
                    }

                    .link-matkul-title {
                        text-decoration: none;
                        color: black;
                        padding: 10px;
                    }

                    .link-matkul-title:hover {
                        text-decoration: none;
                        color: black;
                    }
                </style>
                <div class="card mata-kuliah align-items-center">
                    <div class="matkul-image flex-grow-1 d-flex align-items-start justify-content-around">
                        <img src="" style="width: 320px;" alt="">
                        <div class="matkul-card action">
                            <button type="button" data-bs-toggle="modal" data-bs-target=<?= "#editMatkul" . $a['id'] ?> class="btn btn-primary"><i class="fas fa-edit"></i></button>
                            <button type="button" data-bs-toggle="modal" data-bs-target=<?= "#hapusMatkul" . $a['id'] ?> class="btn btn-danger"><i class="fas fa-trash"></i></button>

                            <!-- Modal Edit Mata Kuliah -->
                            <div class="modal fade" id=<?= "editMatkul" . $a['id'] ?> data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit Mata Kuliah</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action=<?= base_url('/mata-kuliah/update/' . $a['id']); ?> enctype="multipart/form-data" method="post">
                                                <div class="row">
                                                    <div class="col">
                                                        <input required autocomplete="off" type="text" class="form-control" placeholder="Nama Mata Kuliah" aria-label="Nama Mata Kuliah" name="namaMatkul" value="<?= $a['nama']; ?>">
                                                    </div>
                                                    <div class="col">
                                                        <div class="input-group mb-3">
                                                            <label class="input-group-text" for="inputGroupSelect01">Semester</label>
                                                            <select required class="form-select" id="inputGroupSelect01" name="semester">
                                                                <option value="1" <?= $a['semester_id'] == 1 ? 'selected' : ''; ?>>1</option>
                                                                <option value="2" <?= $a['semester_id'] == 2 ? 'selected' : ''; ?>>2</option>
                                                                <option value="3" <?= $a['semester_id'] == 3 ? 'selected' : ''; ?>>3</option>
                                                                <option value="4" <?= $a['semester_id'] == 4 ? 'selected' : ''; ?>>4</option>
                                                                <option value="5" <?= $a['semester_id'] == 5 ? 'selected' : ''; ?>>5</option>
                                                                <option value="6" <?= $a['semester_id'] == 6 ? 'selected' : ''; ?>>6</option>
                                                                <option value="7" <?= $a['semester_id'] == 7 ? 'selected' : ''; ?>>7</option>
                                                                <option value="8" <?= $a['semester_id'] == 8 ? 'selected' : ''; ?>>8</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="input-group mb-3">
                                                    <input required autocomplete="off" type="file" class="form-control" id="inputGroupFile02" name="fileBackground" accept=".jpg, .png, .jpeg">
                                                    <label class="input-group-text" for="inputGroupFile02">Background</label>
                                                </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Hapus Mata Kuliah -->
                            <div class="modal fade" id=<?= "hapusMatkul" . $a['id'] ?> data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="staticBackdropLabel">Yakin Hapus Mata Kuliah??</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action=<?= base_url("/mata-kuliah/delete/" . $a['id']); ?> enctype="multipart/form-data" method="post">
                                                <div class="row">
                                                    <div class="col">
                                                        <input disabled required autocomplete="off" type="text" class="form-control" placeholder="Nama Mata Kuliah" aria-label="Nama Mata Kuliah" name="namaMatkul" value=<?= $a['nama']; ?>>
                                                    </div>
                                                    <div class="col">
                                                        <div class="input-group mb-3">
                                                            <label class="input-group-text" for="inputGroupSelect01">Semester</label>
                                                            <select disabled required class="form-select" id="inputGroupSelect01" name="semester">
                                                                <option value="1" <?= $a['semester_id'] == 1 ? 'selected' : ''; ?>>1</option>
                                                                <option value="2" <?= $a['semester_id'] == 2 ? 'selected' : ''; ?>>2</option>
                                                                <option value="3" <?= $a['semester_id'] == 3 ? 'selected' : ''; ?>>3</option>
                                                                <option value="4" <?= $a['semester_id'] == 4 ? 'selected' : ''; ?>>4</option>
                                                                <option value="5" <?= $a['semester_id'] == 5 ? 'selected' : ''; ?>>5</option>
                                                                <option value="6" <?= $a['semester_id'] == 6 ? 'selected' : ''; ?>>6</option>
                                                                <option value="7" <?= $a['semester_id'] == 7 ? 'selected' : ''; ?>>7</option>
                                                                <option value="8" <?= $a['semester_id'] == 8 ? 'selected' : ''; ?>>8</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="input-group mb-3">
                                                    <input disabled required autocomplete="off" type="file" class="form-control" id="inputGroupFile02" name="fileBackground" accept=".jpg, .png, .jpeg">
                                                    <label class="input-group-text" for="inputGroupFile02">Background</label>
                                                </div>
                                        
                                                               
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Hapus Mata Kuliah -->
                            <div class="modal fade" id=<?= "hapusMatkul" . $a['id'] ?> data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="staticBackdropLabel">Yakin Hapus Mata Kuliah??</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action=<?= base_url("/mata-kuliah/delete/" . $a['id']); ?> enctype="multipart/form-data" method="post">
                                                <div class="row">
                                                    <div class="col">
                                                        <input disabled required autocomplete="off" type="text" class="form-control" placeholder="Nama Mata Kuliah" aria-label="Nama Mata Kuliah" name="namaMatkul" value=<?= $a['nama']; ?>>
                                                    </div>
                                                    <div class="col">
                                                        <div class="input-group mb-3">
                                                            <label class="input-group-text" for="inputGroupSelect01">Semester</label>
                                                            <select disabled required class="form-select" id="inputGroupSelect01" name="semester">
                                                                <option value="1" <?= $a['semester_id'] == 1 ? 'selected' : ''; ?>>1</option>
                                                                <option value="2" <?= $a['semester_id'] == 2 ? 'selected' : ''; ?>>2</option>
                                                                <option value="3" <?= $a['semester_id'] == 3 ? 'selected' : ''; ?>>3</option>
                                                                <option value="4" <?= $a['semester_id'] == 4 ? 'selected' : ''; ?>>4</option>
                                                                <option value="5" <?= $a['semester_id'] == 5 ? 'selected' : ''; ?>>5</option>
                                                                <option value="6" <?= $a['semester_id'] == 6 ? 'selected' : ''; ?>>6</option>
                                                                <option value="7" <?= $a['semester_id'] == 7 ? 'selected' : ''; ?>>7</option>
                                                                <option value="8" <?= $a['semester_id'] == 8 ? 'selected' : ''; ?>>8</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="input-group mb-3">
                                                    <input disabled required autocomplete="off" type="file" class="form-control" id="inputGroupFile02" name="fileBackground" accept=".jpg, .png, .jpeg">
                                                    <label class="input-group-text" for="inputGroupFile02">Background</label>
                                                </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <a href="<?= base_url('/mata-kuliah/detail/' . $a['id']); ?>" class="link-matkul-title">
                        <div class="title mata-kuliah d-flex align-items-center justify-content-center"><?= $a['nama']; ?></div>
                    </a>
                </div>
            <?php
            }
            ?>
        </div>
    </div>

</div>
<?= $this->endSection() ?>

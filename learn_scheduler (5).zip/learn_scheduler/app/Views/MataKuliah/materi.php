<?= $this->extend('/layout/all') ?>

<?= $this->section('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <?php
    // dd(session('message')['materi']);
    ?>

    <!-- Page Heading -->
    <div class="heading d-flex">
        <h1 class="h3 mb-4 text-gray-800" style="font-size: 35px; font-weight: 600;">Materi</h1>
        <div class="tambah-data" style="margin-left:86%;">
            <button type="button" data-bs-toggle="modal" data-bs-target="#tambahMateri" class="btn btn-secondary" style="border-radius: 50%;"><i class="fas fa-plus"></i></button>
        </div>

        <!-- Modal Tambah Materi Mata Kuliah -->
        <div class="modal fade" id="tambahMateri" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Materi</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action=<?= base_url("/materi/save/" . $namaMatkul); ?> method="post" enctype="multipart/form-data">
                            <div class="input-group mb-3">
                                <input required autocomplete="off" type="text" class="form-control" placeholder="Judul Materi" aria-label="Judul Materi" name="judul">
                            </div>
                            <div class="input-group mb-3">
                                <input required autocomplete="off" type="file" class="form-control" id="inputGroupFile02" accept=".pdf, .xlxs, .docx" name="materiFile">
                                <label class="input-group-text" for="inputGroupFile02">Add File</label>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Create</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <style>
        .layout {
            box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
            padding: 20px;
        }

        .list-materi .list {
            box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.5) 0px 1px 3px 1px;
            font-size: 20px;
            padding: 15px;
            border-radius: 5px;
            color: rgb(96, 96, 96);
            margin-top: 20px;
            margin-bottom: 20px;
            font-weight: 500;
        }
    </style>

    <div class="content">
        <div class="container">
            <div class="layout">
                <div class="container"> <br>
                    <h2><b><?= $namaMatkul; ?></b></h2><br>
                    <?php
                    $message = session()->getFlashdata('message');
                    if (!empty($message)) {
                        if ($message == 'berhasil') {
                    ?>
                            <div class="bg-success p-2 text-dark bg-opacity-25 p-3" style="width: 100%; border-radius: 5px;">Status Berhasil🎉</div>
                        <?php
                        } else if ($message == 'gagal') {
                        ?>
                            <div class="bg-danger p-2 text-dark bg-opacity-25 p-3" style="width: 100%; border-radius: 5px;">Status Gagal, Cek kembali🚨</div>
                    <?php
                        }
                    }
                    ?>
                    <?php
                    if (!empty($materi)) {
                    ?>
                        <div class="list-materi">
                            <?php
                            foreach ($materi as $a) {
                            ?>
                                <div class="list">
                                    <div class="d-flex align-items-center">
                                        <div class="title flex-grow-1">
                                            <?= $a['judul']; ?>
                                        </div>
                                        <div class="action">
                                            <button type="button" data-bs-toggle="modal" data-bs-target=<?= "#editMateri" . $a['id'] ?> class="btn"><i class="fas fa-edit"></i></button>
                                            <button type="button" data-bs-toggle="modal" data-bs-target=<?= "#hapusMateri" . $a['id']; ?> class="btn"><i class="fas fa-trash"></i></button>

                                            <!-- Modal Edit Materi Mata Kuliah -->
                                            <div class="modal fade" id=<?= "editMateri" . $a['id'] ?> data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit Materi</h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action=<?= base_url("/materi/edit/" . $a['id']); ?> method="post" enctype="multipart/form-data">
                                                                <div class="input-group mb-3">
                                                                    <input required autocomplete="off" type="text" class="form-control" placeholder="Judul Materi" aria-label="First name" value="<?= $a['judul']; ?>" name="judul">
                                                                </div>
                                                                <div class="input-group mb-3">
                                                                    <input required autocomplete="off" type="file" class="form-control" id="inputGroupFile02" accept=".pdf, .xlxs, .docx" name="materiFile">
                                                                    <label class="input-group-text" for="inputGroupFile02">Add File</label>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary">Edit</button>
                                                        </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>


                                            <!-- Modal Hapus Materi Mata Kuliah -->
                                            <div class="modal fade" id=<?= "hapusMateri" . $a['id']; ?> data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="staticBackdropLabel">Yakin Mengapus??</h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action=<?= base_url("/materi/hapus/" . $a['id']); ?> method="post">
                                                                <div class="input-group mb-3">
                                                                    <input required autocomplete="off" type="text" class="form-control" placeholder="Judul Materi" aria-label="First name" value="<?= $a['judul']; ?>" disabled>
                                                                </div>
                                                                <div class="input-group mb-3">
                                                                    <input required autocomplete="off" type="file" class="form-control" id="inputGroupFile02" disabled>
                                                                    <label class="input-group-text" for="inputGroupFile02">Add File</label>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-success">Ya</button>
                                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tidak</button>
                                                        </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    <?php
                    } else {
                    ?>
                        <div class="list-materi">
                            <div class="list">
                                <div class="d-flex align-items-center">
                                    <div class="title flex-grow-1">
                                        Materi belum ditambahkan...
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>

                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?= $this->endSection(); ?>
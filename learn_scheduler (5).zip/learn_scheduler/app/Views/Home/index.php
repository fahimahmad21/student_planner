<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #FFFFFF; /* Set the background color of the entire page to white */
            font-family: 'Rubik', Arial, sans-serif;
        }
        .dashboard-box {
            border: none; /* Remove border from the entire box */
            padding: 20px;
            height: 100%;
            margin-bottom: 20px; /* Add margin between boxes */
        }
        .box-content {
            border: 1px solid #dee2e6; /* Add border only to the content inside the box */
            border-radius: 0.25rem;
            padding: 15px;
            margin-top: 15px;
            background-color: #f8f9fa; /* Set background color of the content to light grey */
        }
        #todo-list ul {
            list-style-type: none; /* Remove bullets */
            padding: 0; /* Remove padding */
        }
        #todo-list li {
            margin-bottom: 10px; /* Add space between items */
        }
        .calendar {
            margin: 20px auto;
            background-color: #f0f0f0;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
        }
        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .calendar-header h2 {
            margin: 0;
            font-size: 24px;
            display: flex;
            align-items: center;
        }
        .calendar-header h2 .dropdown {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }
        .calendar-header h2 .dropdown-content {
            display: none;
            position: absolute;
            background-color: #fff;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 5px;
            padding: 5px;
            right: 0;
        }
        .calendar-header h2 .dropdown-content select,
        .calendar-header h2 .dropdown-content button {
            width: 100px;
            padding: 5px;
            font-size: 16px;
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-left: 10px;
        }
        .calendar-header h2 .dropdown-content button {
            cursor: pointer;
        }
        .calendar-header h2 .dropdown:hover .dropdown-content {
            display: block;
        }
        .fa-angle-down {
            margin-left: 5px;
            cursor: pointer;
        }
        .days {
            display: flex;
            flex-wrap: wrap;
        }
        .day {
            width: 14.28%;
            text-align: center;
            padding: 10px 0;
            box-sizing: border-box;
            border-bottom: 1px solid black; /* Garis bawah hanya pada nama hari */
        }
        .dates {
            display: flex;
            flex-wrap: wrap;
        }
        .date {
            width: 14.28%;
            text-align: center;
            padding: 10px 0;
            box-sizing: border-box;
        }
        .today {
            background-color: #b0b0b0;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: inline-block;
            line-height: 30px;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Dashboard</h1>

    <div class="row">
        <!-- Box 1: Hi User! What are your plans for today? -->
        <div class="col-md-6">
            <div class="dashboard-box">
                <h4>Hi User!</h4>
                <h4>What are your plans for today?</h4>
            </div>
        </div>
        <!-- Box 2: Calendar -->
        <div class="col-md-6">
            <div class="dashboard-box">
                <h4>Calendar</h4>
                <div class="box-content">
                    <!-- Placeholder for Calendar -->
                    <?php
                    function build_calendar($month, $year) {
                        // Array hari dalam seminggu dimulai dari Senin
                        $daysOfWeek = array('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun');

                        // Menghitung jumlah hari dalam bulan yang diberikan
                        $numDaysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);

                        // Mendapatkan tanggal hari ini
                        $dateToday = date('Y-m-d');

                        // Membuat string untuk menyimpan kalender HTML
                        $calendar = "<div class='calendar'>";
                        $calendar .= "<div class='calendar-header'>";
                        $calendar .= "<h2>";
                        $calendar .= "<span id='calendar-month'>" . date('F', mktime(0, 0, 0, $month, 1, $year)) . "</span>, ";
                        $calendar .= "<span id='calendar-year'>$year</span>";
                        $calendar .= "<div class='dropdown'>";
                        $calendar .= "<i class='fas fa-angle-down' id='dropdown-icon' onclick='toggleDropdown()'></i>";
                        $calendar .= "<div class='dropdown-content' id='dropdown-content'>";
                        $calendar .= "<form method='POST' action=''>";
                        $calendar .= "<select id='month-dropdown' name='month'>";
                        $calendar .= "<option value='1'>January</option>";
                        $calendar .= "<option value='2'>February</option>";
                        $calendar .= "<option value='3'>March</option>";
                        $calendar .= "<option value='4'>April</option>";
                        $calendar .= "<option value='5'>May</option>";
                        $calendar .= "<option value='6'>June</option>";
                        $calendar .= "<option value='7'>July</option>";
                        $calendar .= "<option value='8'>August</option>";
                        $calendar .= "<option value='9'>September</option>";
                        $calendar .= "<option value='10'>October</option>";
                        $calendar .= "<option value='11'>November</option>";
                        $calendar .= "<option value='12'>December</option>";
                        $calendar .= "</select>";
                        $calendar .= "<select id='year-dropdown' name='year'>";
                        for ($y = 2000; $y <= 2030; $y++) {
                            $selected = ($y == $year) ? 'selected' : '';
                            $calendar .= "<option value='$y' $selected>$y</option>";
                        }
                        $calendar .= "</select>";
                        $calendar .= "<button type='submit'>Tampilkan Kalender</button>";
                        $calendar .= "</form>";
                        $calendar .= "</div>";
                        $calendar .= "</div>";
                        $calendar .= "</h2>";
                        $calendar .= "</div>";

                        // Menampilkan nama hari dalam seminggu
                        $calendar .= "<div class='days'>";
                        foreach ($daysOfWeek as $day) {
                            $calendar .= "<div class='day'>$day</div>";
                        }
                        $calendar .= "</div>";

                        // Menghitung hari pertama dalam bulan (0: Minggu, 1: Senin, ..., 6: Sabtu)
                        $firstDayOfWeek = date('w', mktime(0, 0, 0, $month, 1, $year));

                        // Menghitung jumlah hari yang perlu ditampilkan sebelum tanggal 1
                        $daysBefore = ($firstDayOfWeek + 6) % 7;

                        // Menampilkan tanggal dalam kalender
                            $calendar .= "<div class='dates'>";
                            for ($i = 1 - $daysBefore; $i <= $numDaysInMonth; $i++) {
                                if ($i <= 0) {
                                    $calendar .= "<div class='date'></div>"; // Tanggal sebelum bulan dimulai
                                } else {
                                    $currentDate = date('Y-m-d', mktime(0, 0, 0, $month, $i, $year));
                                    $calendar .= "<div class='date'>" . ($currentDate == $dateToday ? "<span class='today'>$i</span>" : "$i") . "</div>";
                                }
                            }
                            $calendar .= "</div>";

                            $calendar .= "</div>"; // Tutup kalender

                            return $calendar;
                        }

                        // Mengambil bulan dari POST jika tersedia, jika tidak menggunakan bulan saat ini
                        $month = isset($_POST['month']) ? $_POST['month'] : date('n');
                        // Mengambil tahun dari POST jika tersedia, jika tidak menggunakan tahun saat ini
                        $year = isset($_POST['year']) ? $_POST['year'] : date('Y');

                        // Memanggil fungsi untuk membangun kalender
                        echo build_calendar($month, $year);
                        ?>

                        <script>
                            function toggleDropdown() {
                                var dropdownContent = document.getElementById('dropdown-content');
                                dropdownContent.style.display = (dropdownContent.style.display === 'block') ? 'none' : 'block';
                            }

                            // Set default values for the dropdowns
                            document.getElementById('month-dropdown').value = <?php echo $month; ?>;
                            document.getElementById('year-dropdown').value = <?php echo $year; ?>;
                        </script>
                    <div id="calendar"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Box 3: Notification -->
        <div class="col-md-6">
            <div class="dashboard-box">
                <h4>Notification</h4>
                <div class="box-content">
                    <ul id="notification-list">
                        <li><strong>Tugas Proyek</strong>: Deadline Tugas Proyek Web Programming tanggal 25 Juni 2024 jam 23:59. Ayo Segera Kerjakan!</li>
                        <li><strong>Ujian</strong>: Persiapkan diri, H-5 menuju Ujian Tengah Semester. BELAJAR YANG SUNGGUH-SUNGGUH!</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Box 4: To Do List -->
        <div class="col-md-6">
            <div class="dashboard-box">
                <h4>To Do List</h4>
                <div class="box-content">
                    <div id="todo-list">
                        <ul>
                            <li><input type="checkbox"> Rapat bulanan organisasi</li>
                            <li><input type="checkbox"> Tugas Besar Web Programming</li>
                            <li><input type="checkbox"> Tugas membuat modul Keamanan Komputer</li>
                            <li><input type="checkbox"> Tugas membuat poster Komputer Grafik</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- Optional: JavaScript for Calendar -->
<script>
    // You can add JavaScript here to integrate a calendar plugin if needed
</script>

</body>
</html>

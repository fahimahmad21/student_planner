<!-- Sidebar -->
<ul class="navbar-nav sidebar sidebar-dark accordion" id="accordionSidebar" style="background-color: #040348;">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-text mx-3 text-white">Learn Scheduler</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Interface Section -->
    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href="/">
            <div class="bg-white rounded py-2 px-3">
                <i class="fas fa-tachometer-alt fa-fw text-dark"></i>
                <span class="text-dark">Dashboard</span>
            </div>
        </a>
    </li>
    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href=<?= base_url('/mata-kuliah'); ?>>
            <div class="bg-white rounded py-2 px-3">
                <i class="fas fa-book fa-fw text-dark"></i>
                <span class="text-dark">Mata Kuliah</span>
            </div>
        </a>
    </li>
    

    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href="jadwal_kuliah.html">
            <div class="bg-white rounded py-2 px-3">
                <i class="far fa-calendar-alt fa-fw text-dark"></i>
                <span class="text-dark">Jadwal Kuliah</span>
            </div>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Calendar Section -->
    <div class="sidebar-heading text-white">
        Calendar
    </div>
    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href="calendar.html">
            <div class="bg-white rounded py-2 px-3">
                <i class="far fa-calendar fa-fw text-dark"></i>
                <span class="text-dark">Calendar</span>
            </div>
        </a>
    </li>
    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href="notifikasi.html">
            <div class="bg-white rounded py-2 px-3">
                <i class="far fa-bell fa-fw text-dark"></i>
                <span class="text-dark">Notifikasi</span>
            </div>
        </a>
    </li>
    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href="timer.html">
            <div class="bg-white rounded py-2 px-3">
                <i class="far fa-clock fa-fw text-dark"></i>
                <span class="text-dark">Timer</span>
            </div>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Group Project Section -->
    <div class="sidebar-heading text-white">
        Grup Project
    </div>
    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href="tugaskelompok.html">
            <div class="bg-white rounded py-2 px-3">
                <i class="fas fa-users fa-fw text-dark"></i>
                <span class="text-dark">Tugas Kelompok</span>
            </div>
        </a>
    </li>
    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href="todolist_project.html">
            <div class="bg-white rounded py-2 px-3">
                <i class="fas fa-clipboard-list fa-fw text-dark"></i>
                <span class="text-dark">To do list</span>
            </div>
        </a>
    </li>
    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href="meeting.html">
            <div class="bg-white rounded py-2 px-3">
                <i class="fas fa-handshake fa-fw text-dark"></i>
                <span class="text-dark">Meeting</span>
            </div>
        </a>
    </li>
    <li class="nav-item" style="padding-bottom: 0;">
        <a class="nav-link collapsed text-white" href="chat.html">
            <div class="bg-white rounded py-2 px-3">
                <i class="fas fa-comments fa-fw text-dark"></i>
                <span class="text-dark">Chat</span>
            </div>
        </a>
    </li>
    <li class="nav-item" style="padding-bottom: 0;">
    <a class="nav-link collapsed text-white" href="http://localhost:3000/">
        <div class="bg-white rounded py-2 px-3">
            <i class="fas fa-desktop fa-fw text-dark"></i>
            <span class="text-dark">Web UI</span>
        </div>
    </a>
</li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>
<!-- End of Sidebar -->

<style>
    .nav-item:hover .bg-white {
        background-color: #ffd700 !important;
        /* Warna kuning emas saat hover */
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1) !important;
        /* Bayangan saat hover */
    }
</style>
<!-- views/webui_view.php -->

<h1>Ollama Data</h1>

<?php if (!empty($data)): ?>
    <ul>
        <?php foreach ($data as $item): ?>
            <li><?= $item ?></li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>No data available.</p>
<?php endif; ?>
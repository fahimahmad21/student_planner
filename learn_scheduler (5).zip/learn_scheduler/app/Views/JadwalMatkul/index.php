<?= $this->extend('/layout/all') ?>

<?= $this->section('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <?php
    // dd(session('message')['materi']);
    ?>

    <!-- Page Heading -->
    <div class="heading d-flex">
        <h1 class="h3 mb-4 text-gray-800 flex-grow-1" style="font-size: 35px; font-weight: 600;">Jadwal Kuliah</h1>
        <div class="tambah-data" style="margin-right:20px;">
            <button type="button" data-bs-toggle="modal" data-bs-target="#tambahJadwal" class="btn btn-secondary" style="border-radius: 50%;"><i class="fas fa-plus"></i></button>
        </div>

        <!-- Modal Tambah Jadwal Mata Kuliah -->
        <div class="modal fade" id="tambahJadwal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Jadwal</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action=<?= base_url("/jadwal_kuliah/save/"); ?> method="post" enctype="multipart/form-data">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" placeholder="Hari" name="hari">
                            </div>
                            <div class="input-group mb-3">
                                <div class="row">
                                    <div class="col">
                                        <!-- <label for="#timeInput">Jam Mulai</label> -->
                                        <input type="time" class="form-control" id="timeInput" name="jamMulai">
                                    </div>
                                    <div class="col">
                                        <!-- <label for="#timeInput">Jam Berakhir</label> -->
                                        <input type="time" class="form-control" id="timeInput" name="jamBerakhir">
                                    </div>
                                </div>
                            </div>
                            <div class="input-group mb-3">
                                <input required autocomplete="off" type="text" class="form-control" placeholder="Mata Kuliah" aria-label="Mata Kuliah" name="mataKuliah">
                            </div>
                            <div class="input-group mb-3">
                                <input required autocomplete="off" type="text" class="form-control" id="inputGroupFile02" placeholder="ruangan" name="ruangan">
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Create</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <style>
        .layout {
            box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
            padding: 20px;
            background-color: rgb(246, 246, 246);
            border-radius: 10px;
        }


        .col .title {
            font-size: 25px;
            font-weight: 600;
        }

        .col .btn.jam {
            border-radius: 20px;
            padding: 5px;
            width: 60%;
            margin: 5px;
            background-color: rgb(165, 165, 165);
            box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
            font-weight: 600;
        }

        .col.deskripsi {
            padding: 5px;
            font-weight: 600;
            align-items: center;
        }

        .garis {
            border-bottom: 2px solid #d2d1d1;
            margin-top: 10px;
            margin-bottom: 10px;
        }
    </style>

    <div class="content">
        <div class="layout">
            <div class="row">
                <div class="col">
                    <div class="title">Senin</div>
                    <div class="row isi-jadwal">
                        <div class="col-4">
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">14:41 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">15:00 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                        </div>
                        <div class="col deskripsi">
                            <div class="row namaMatkul mb-2">Sistem Informasi Manajement</div>
                            <div class="row namaRuangan">
                                <div class="col-1">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="col">Ruang 109, FTI</div>
                            </div>
                        </div>
                    </div>
                    <div class="garis"></div>
                </div>
                <div class="col">
                    <div class="title">Selasa</div>
                    <div class="row isi-jadwal">
                        <div class="col-4">
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">14:41 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">15:00 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                        </div>
                        <div class="col deskripsi">
                            <div class="row namaMatkul mb-2">Sistem Informasi Manajement</div>
                            <div class="row namaRuangan">
                                <div class="col-1">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="col">Ruang 109, FTI</div>
                            </div>
                        </div>
                    </div>
                    <div class="garis"></div>
                </div>
                <div class="col">
                    <div class="title">Rabu</div>
                    <div class="row isi-jadwal">
                        <div class="col-4">
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">14:41 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">15:00 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                        </div>
                        <div class="col deskripsi">
                            <div class="row namaMatkul mb-2">Sistem Informasi Manajement</div>
                            <div class="row namaRuangan">
                                <div class="col-1">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="col">Ruang 109, FTI</div>
                            </div>
                        </div>
                    </div>
                    <div class="garis"></div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="title">Kamis</div>
                    <div class="row isi-jadwal">
                        <div class="col-4">
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">14:41 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">15:00 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                        </div>
                        <div class="col deskripsi">
                            <div class="row namaMatkul mb-2">Sistem Informasi Manajement</div>
                            <div class="row namaRuangan">
                                <div class="col-1">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="col">Ruang 109, FTI</div>
                            </div>
                        </div>
                    </div>
                    <div class="garis"></div>
                </div>
                <div class="col">
                    <div class="title">Jum'at</div>
                    <div class="row isi-jadwal">
                        <div class="col-4">
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">14:41 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                            <div class="row">
                                <button class="btn jam">
                                    <div class="jam">15:00 <i class="far fa-clock"></i></div>
                                </button>
                            </div>
                        </div>
                        <div class="col deskripsi">
                            <div class="row namaMatkul mb-2">Sistem Informasi Manajement</div>
                            <div class="row namaRuangan">
                                <div class="col-1">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="col">Ruang 109, FTI</div>
                            </div>
                        </div>
                    </div>
                    <div class="garis"></div>
                </div>
                <div class="col"></div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?= $this->endSection(); ?>
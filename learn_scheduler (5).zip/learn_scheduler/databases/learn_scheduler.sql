-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2024 at 07:23 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `learn_scheduler`
--

-- --------------------------------------------------------

--
-- Table structure for table `aktivitas_belajar`
--

CREATE TABLE `aktivitas_belajar` (
  `id` int(11) NOT NULL,
  `pengguna_id` int(11) NOT NULL,
  `mata_kuliah_id` int(11) NOT NULL,
  `tugas_id` int(11) NOT NULL,
  `catatan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `catatan`
--

CREATE TABLE `catatan` (
  `id` int(11) NOT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `topik` varchar(100) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `catatan`
--

INSERT INTO `catatan` (`id`, `mata_kuliah_id`, `topik`, `deskripsi`) VALUES
(1, 1, 'Kriptografi bagian 1 dan 2', 'Keamanan komputer adalah praktek melindungi sistem komputer dan informasi dari ancaman dan akses yang tidak sah. Tujuan utama keamanan komputer adalah menjaga kerahasiaan, integritas, dan ketersediaan informasi (CIA Triad). Tujuan keamanan jaringan yaitu untuk kerahasiaan, integritas, ketersediaan, autentikasi.'),
(2, 2, 'Cloud menurut AWS', 'Pendekatan komputasi awan menurut Amazon Web Services. Cloud Computing adalah model komputasi yang memungkinkan akses on-demand melalui internet ke kumpulan sumber daya komputasi yang dapat dikonfigurasi, seperti server, penyimpanan, jaringan, aplikasi, dan layanan lainnya. Virtualization adalah teknologi yang memungkinkan pembuatan versi virtual dari sesuatu yang biasanya berbentuk fisik, seperti perangkat keras komputer, sistem operasi, perangkat penyimpanan, atau sumber daya jaringan.'),
(3, 3, 'Pentingnya etika profesi', 'Etika profesional adalah seperangkat prinsip dan standar moral yang memandu perilaku dan praktik individu dalam profesi tertentu. Etika profesional berfungsi sebagai pedoman untuk memastikan bahwa para profesional bertindak dengan integritas, tanggung jawab, dan rasa hormat terhadap klien, kolega, dan masyarakat.'),
(4, 4, 'Manajemen data dan manajemen pengetahuan', 'Manajemen Data adalah disiplin yang berkaitan dengan pengelolaan siklus hidup data, mulai dari pengumpulan, penyimpanan, pengolahan, hingga penggunaan data. Tujuan manajemen data adalah untuk memastikan data tersedia, akurat, terjamin keamanannya, dan dapat diakses oleh pengguna yang berwenang pada waktu yang tepat.'),
(5, 5, 'Definisi Komputer grafik', 'Komputer grafik adalah bidang yang luas dan terus berkembang, menawarkan berbagai teknik dan aplikasi yang penting dalam berbagai industri dan disiplin ilmu. Dengan pemahaman yang kuat tentang prinsip-prinsip dasar dan teknologi terkini, para profesional komputer grafik dapat menciptakan solusi visual yang inovatif dan menarik.'),
(6, 6, 'Sejarah pedaraban Islam', 'Peradaban Islam merujuk pada periode sejarah yang dipengaruhi oleh agama Islam, dimulai dari awal penyebaran Islam pada abad ke-7 Masehi hingga masa keemasan peradaban Islam pada abad ke-14 Masehi. Peradaban ini mencakup aspek-aspek budaya, sosial, ekonomi, dan politik yang berkembang di dunia Muslim selama periode ini.'),
(7, 7, 'Hypertext markup language (HTML)', 'HTML (HyperText Markup Language) adalah bahasa markup standar yang digunakan untuk membuat dan mendesain halaman web. HTML memberikan struktur dasar bagi sebuah halaman web dengan menggunakan serangkaian elemen dan tag yang mendefinisikan berbagai elemen seperti teks, gambar, tautan, tabel, formulir, dan banyak lagi. Komponen utama HTML : Elemen, Atribut, Teks dan konten, Struktur Dokumen.'),
(8, 8, 'Kedudukan bahasa Indonesia dan bahasa asing', 'Peran bahasa Indonesia dan bahasa asing dalam komunikasi'),
(9, 9, 'Pengantar jaringan komputer dan komunikasi data', 'Jaringan Komputer adalah sistem yang terdiri dari dua atau lebih komputer yang saling terhubung untuk berbagi sumber daya dan informasi. Komunikasi Data adalah pertukaran data atau informasi melalui saluran komunikasi, seperti kabel atau nirkabel.');

-- --------------------------------------------------------

--
-- Table structure for table `catatan_meeting`
--

CREATE TABLE `catatan_meeting` (
  `id` int(11) NOT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `tugas_proyek_id` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `catatan_meeting`
--

INSERT INTO `catatan_meeting` (`id`, `mata_kuliah_id`, `tugas_proyek_id`, `tanggal`, `deskripsi`) VALUES
(1, 7, 1, '2024-03-27', 'Latar belakang belum ada yang sesuai dengan inti permasalahan, power point untuk presentasi terlalu kompleks (diambil yang intinya saja)');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `pengguna_id` int(11) DEFAULT NULL,
  `proyek_grup_id` int(11) DEFAULT NULL,
  `notifikasi` tinyint(1) DEFAULT 0,
  `pesan` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_kuliah`
--

CREATE TABLE `jadwal_kuliah` (
  `id` int(11) NOT NULL,
  `mata_kuliah_id` int(11) NOT NULL,
  `hari` varchar(10) NOT NULL,
  `waktu` time NOT NULL,
  `ruang` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_meeting`
--

CREATE TABLE `jadwal_meeting` (
  `id` int(11) NOT NULL,
  `tugas_proyek_id` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu` time DEFAULT NULL,
  `lokasi` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jadwal_meeting`
--

INSERT INTO `jadwal_meeting` (`id`, `tugas_proyek_id`, `tanggal`, `waktu`, `lokasi`) VALUES
(1, 1, '2024-03-27', '15:00:00', 'Burjo DOI 5');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_ujian`
--

CREATE TABLE `jadwal_ujian` (
  `id` int(11) NOT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `hari` varchar(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu_mulai` time DEFAULT NULL,
  `waktu_selesai` time DEFAULT NULL,
  `lokasi` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jadwal_ujian`
--

INSERT INTO `jadwal_ujian` (`id`, `mata_kuliah_id`, `hari`, `tanggal`, `waktu_mulai`, `waktu_selesai`, `lokasi`) VALUES
(1, 1, 'Senin', '2024-05-06', '10:00:00', '11:30:00', '304'),
(2, 2, 'Selasa', '2024-05-07', '08:00:00', '09:30:00', '304'),
(3, 3, 'Selasa', '2024-05-07', '10:00:00', '11:30:00', '302'),
(4, 4, 'Rabu', '2024-05-08', '08:00:00', '09:30:00', '305'),
(5, 5, 'Rabu', '2024-05-08', '13:00:00', '14:30:00', '307'),
(6, 6, 'Jumat', '2024-05-10', '10:00:00', '11:30:00', '304'),
(7, 7, 'Senin', '2024-05-13', '08:30:00', '09:30:00', '302'),
(8, 8, 'Senin', '2024-05-13', '13:00:00', '14:30:00', '302'),
(9, 9, 'Kamis', '2024-05-16', '13:00:00', '14:30:00', '302');

-- --------------------------------------------------------

--
-- Table structure for table `kalender_kegiatan`
--

CREATE TABLE `kalender_kegiatan` (
  `id` int(11) NOT NULL,
  `pengguna_id` int(11) DEFAULT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu_mulai` time DEFAULT NULL,
  `waktu_selesai` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kehadiran`
--

CREATE TABLE `kehadiran` (
  `id` int(11) NOT NULL,
  `pengguna_id` int(11) DEFAULT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `pertemuan` varchar(30) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `status` enum('hadir','tidak hadir') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mata_kuliah`
--

CREATE TABLE `mata_kuliah` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mata_kuliah`
--

INSERT INTO `mata_kuliah` (`id`, `nama`, `semester_id`) VALUES
(1, 'Keamanan Komputer', 4),
(2, 'Cloud Computing', 4),
(3, 'Etika Professional', 4),
(4, 'Sistem Informasi Manajemen', 4),
(5, 'Komputer Grafik', 4),
(6, 'Peradaban Islam', 4),
(7, 'Web Programming', 4),
(8, 'Bahasa Indonesia', 4),
(9, 'Jaringan Komputer dan Komunikasi Data', 4);

-- --------------------------------------------------------

--
-- Table structure for table `materi`
--

CREATE TABLE `materi` (
  `id` int(11) NOT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `materi`
--

INSERT INTO `materi` (`id`, `mata_kuliah_id`, `judul`, `file_path`) VALUES
(1, 1, 'RSP mata kuliah', 'path/to/file'),
(2, 1, 'Pengantar keamanan komputer 1', 'path/to/file'),
(3, 1, 'Pengantar keamanan komputer 2', 'path/to/file'),
(4, 1, 'Kriptografi bagian 1', 'path/to/file'),
(5, 1, 'Kriptografi bagian 2', 'path/to/file'),
(6, 1, 'Keamanan sistem informasi', 'path/to/file'),
(7, 1, 'Kisi-kisi uts', 'path/to/file'),
(8, 1, 'UTS', 'path/to/file'),
(9, 1, 'Panduan pelaporan insiden', 'path/to/file'),
(10, 1, 'Keamanan jaringan pada sistem pemerintahan elektronik', 'path/to/file'),
(11, 1, 'Pendahuluan keamanan siber', 'path/to/file'),
(12, 2, 'Pengenalan cloud computing', 'path/to/file'),
(13, 2, 'Cloud menurut AWS', 'path/to/file'),
(14, 2, 'IaaS explained', 'path/to/file'),
(15, 2, 'PaaS explained', 'path/to/file'),
(16, 2, 'SaaS explained', 'path/to/file'),
(17, 2, 'Virtualization', 'path/to/file'),
(18, 2, 'Virtualization part 2', 'path/to/file'),
(19, 2, 'UTS', 'path/to/file'),
(20, 2, 'Hypervisor', 'path/to/file'),
(21, 2, 'Xen Virtualization', 'path/to/file'),
(22, 2, 'Container Virtualization', 'path/to/file'),
(23, 2, 'Docker', 'path/to/file'),
(24, 2, 'Amazon EC2', 'path/to/file'),
(25, 2, 'Cloud computing security', 'path/to/file'),
(26, 2, 'Fog computing', 'path/to/file'),
(27, 2, 'UAS', 'path/to/file'),
(28, 3, 'RPS Etika professional', 'path/to/file'),
(29, 3, 'Etika profesi', 'path/to/file'),
(30, 3, 'Pelanggaran etika profesi', 'path/to/file'),
(31, 3, 'Pentingnya etika profesi', 'path/to/file'),
(32, 3, 'Kode etik profesi bidang IT', 'path/to/file'),
(33, 3, 'Latihan etika dan tes formatif', 'path/to/file'),
(34, 3, 'Kisi-kisi uts etika professional', 'path/to/file'),
(35, 3, 'UTS', 'path/to/file'),
(36, 3, 'Hak cipta (HKI)', 'path/to/file'),
(37, 3, 'Hak paten dan paten sederhana (HKI)', 'path/to/file'),
(38, 4, 'Sistem informasi konsep dan manajemen', 'path/to/file'),
(39, 4, 'Organisasi modern dalam era digital', 'path/to/file'),
(40, 4, 'Software technology', 'path/to/file'),
(41, 4, 'Sistem informasi dalam manajemen', 'path/to/file'),
(42, 4, 'UTS', 'path/to/file'),
(43, 4, 'Manajemen data dan manajemen pengetahuan', 'path/to/file'),
(44, 7, 'Pengenalan teknologi internet', 'path/to/file'),
(45, 7, 'Hypertext markup language (HTML)', 'path/to/file'),
(46, 7, 'HTML form', 'path/to/file'),
(47, 7, 'CSS', 'path/to/file'),
(48, 7, 'JavaScript', 'path/to/file'),
(49, 7, 'PHP part 1', 'path/to/file'),
(50, 7, 'PHP part 2', 'path/to/file'),
(51, 7, 'Presentasi laporan latar belakang', 'path/to/file'),
(52, 8, 'Kedudukan bahasa Indonesia dan bahasa asing', 'path/to/file'),
(53, 9, 'Pengantar jaringan komputer dan komunikasi data', 'path/to/file'),
(54, 9, 'Modul osi layer dan lapisan fisik', 'path/to/file'),
(55, 9, 'Lapisan data link', 'path/to/file'),
(56, 9, 'Lapisan jaringan part 1', 'path/to/file'),
(57, 9, 'Lapisan jaringan part 2', 'path/to/file'),
(58, 9, 'Subnetting IP address', 'path/to/file'),
(59, 9, 'Routing protocol', 'path/to/file'),
(60, 9, 'Cisco network fundamentals', 'path/to/file'),
(61, 9, 'Lapisan Transport', 'path/to/file'),
(62, 9, 'Lapisan Transport JFK versi Indonesia', 'path/to/file');

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi`
--

CREATE TABLE `notifikasi` (
  `id` int(11) NOT NULL,
  `pengguna_id` int(11) DEFAULT NULL,
  `tipe` enum('tugas','pembayaran','ujian','proyek','meeting','materi') DEFAULT NULL,
  `referensi_id` int(11) DEFAULT NULL,
  `pesan` text DEFAULT NULL,
  `status` enum('terbaca','belum terbaca') DEFAULT 'belum terbaca',
  `tanggal_deadline` date DEFAULT NULL,
  `waktu_deadline` time DEFAULT NULL,
  `tanggal_dibuat` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int(11) NOT NULL,
  `pengguna_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `periode` varchar(50) DEFAULT NULL,
  `jumlah` decimal(10,2) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `status` enum('lunas','belum lunas') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `pengguna_id`, `semester_id`, `periode`, `jumlah`, `tanggal`, `status`) VALUES
(1, 1, 3, 'KRS', 1800000.00, '2022-07-01', 'lunas'),
(2, 1, 3, 'UTS', 2100000.00, '2022-10-28', 'lunas'),
(3, 1, 3, 'UAS', 2100000.00, '2023-01-05', 'lunas'),
(4, 1, 4, 'KRS', 1800000.00, '2023-07-15', 'lunas'),
(5, 1, 4, 'UTS', 2100000.00, '2023-06-12', 'lunas'),
(6, 1, 4, 'UAS', 2100000.00, '2024-07-29', 'belum lunas');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `kata_sandi` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id`, `nama`, `email`, `kata_sandi`) VALUES
(1, 'Arfiana', 'arfianaa25@gmail.com', 'arfianaa25');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna_mata_kuliah`
--

CREATE TABLE `pengguna_mata_kuliah` (
  `id` int(11) NOT NULL,
  `pengguna_id` int(11) DEFAULT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengguna_mata_kuliah`
--

INSERT INTO `pengguna_mata_kuliah` (`id`, `pengguna_id`, `mata_kuliah_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9);

-- --------------------------------------------------------

--
-- Table structure for table `proyek_grup`
--

CREATE TABLE `proyek_grup` (
  `id` int(11) NOT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `nama_tugas` varchar(100) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `proyek_grup`
--

INSERT INTO `proyek_grup` (`id`, `mata_kuliah_id`, `nama_tugas`, `deskripsi`) VALUES
(1, 7, 'Tugas Besar membuat aplikasi berbasis Web', 'Membuat Develop aplikasi student planner berbasis web menggunakan Codeigniter, Bootstrap, MySQL (MariaDB)');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_akhir` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `nama`, `tanggal_mulai`, `tanggal_akhir`) VALUES
(1, 'Semester 1', '2024-07-09', '2024-10-09'),
(2, 'Semester 2', '2024-11-09', '2025-02-09'),
(3, 'Semester 3', '2025-03-09', '2025-06-09'),
(4, 'Semester 4', '2025-07-09', '2025-10-09');

-- --------------------------------------------------------

--
-- Table structure for table `timer`
--

CREATE TABLE `timer` (
  `id` int(11) NOT NULL,
  `pengguna_id` int(11) DEFAULT NULL,
  `aktivitas_belajar_id` int(11) DEFAULT NULL,
  `tugas_id` int(11) DEFAULT NULL,
  `kalender` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `todolist`
--

CREATE TABLE `todolist` (
  `id` int(11) NOT NULL,
  `deskripsi_tugas` text NOT NULL,
  `status` enum('belum selesai','sedang dikerjakan','selesai') DEFAULT 'belum selesai',
  `tenggat_waktu` date DEFAULT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `proyek_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `todolist`
--

INSERT INTO `todolist` (`id`, `deskripsi_tugas`, `status`, `tenggat_waktu`, `mata_kuliah_id`, `proyek_id`) VALUES
(1, 'Mengerjakan tugas kelompok membuat buku', 'selesai', '2024-05-28', 1, NULL),
(2, 'Mengerjakan tugas kelompok meresume materi tentang cyber security', 'selesai', '2024-06-11', 1, NULL),
(3, 'Tugas presentasi BAB IV modul ajar bahasa Indonesia', '', '2024-06-21', 8, NULL),
(4, 'Mencari jurnal sinta 1-5', 'sedang dikerjakan', '2024-06-11', 8, NULL),
(5, 'Mencatat resume setiap bab modul ajar Bahasa Indonesia', 'sedang dikerjakan', '2024-06-14', 8, NULL),
(6, 'Membuat aplikasi menggunakan docker', 'sedang dikerjakan', '2024-06-13', 2, NULL),
(7, 'Menjelaskan pelanggaran etika professional di bidang IT', 'selesai', '2024-06-05', 3, NULL),
(8, 'Menganalisis masalah etika professional pada lingkungan kampus', 'sedang dikerjakan', '2024-06-15', 3, NULL),
(9, 'Tugas pertemuan 2 modul OSI layer dan lapisan fisik', 'selesai', '2024-06-01', 9, NULL),
(10, 'Tugas pertemuan 4 modul lapisan jaringan', 'sedang dikerjakan', '2024-06-14', 9, NULL),
(11, 'Tugas pertemuan 6 subneting mask', '', '2024-06-28', 9, NULL),
(12, 'Membuat desain poster dengan bertema SDGs', '', '2024-06-27', 5, NULL),
(13, 'Membuat Essay Sejarah', 'sedang dikerjakan', '2024-06-18', 6, NULL),
(14, 'Analisis tokoh', 'sedang dikerjakan', '2024-06-15', 6, NULL),
(15, 'Rancangan Sistem Informasi Manajemen untuk UKM', 'selesai', '2024-06-10', 4, NULL),
(16, 'Membuat Aplikasi Sederhana untuk Manajemen Inventaris', '', '2024-06-29', 4, NULL),
(17, 'Tugas 1 HTML', 'selesai', '2024-03-23', 7, NULL),
(18, 'Tugas 2 CSS', 'selesai', '2024-04-28', 7, NULL),
(19, 'Latihan PHP', 'selesai', '2024-05-26', 7, NULL),
(20, 'Latihan CRUD', 'selesai', '2024-05-31', 7, NULL),
(21, 'TUBES pemaparan laporan bab 1', 'selesai', '2024-06-04', 7, NULL),
(22, 'TUBES pemaparan laporan bab 2', 'selesai', '2024-06-11', 7, NULL),
(23, 'TUBES rancangan user interface', 'sedang dikerjakan', '2024-06-25', 7, NULL),
(24, 'TUBES mempresentasikan aplikasi student planner', '', '2024-07-02', 7, NULL),
(25, 'TUBES mempresentasikan aplikasi student planner (cont)', '', '2024-07-08', 7, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `to_do_list_user`
--

CREATE TABLE `to_do_list_user` (
  `id` int(11) NOT NULL,
  `deskripsi_tugas` varchar(255) DEFAULT NULL,
  `status` enum('sudah dikerjakan','belum dikerjakan','akan dikerjakan') DEFAULT NULL,
  `tenggat_waktu` date DEFAULT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `pengguna_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tugas`
--

CREATE TABLE `tugas` (
  `id` int(11) NOT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `tanggal_deadline` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tugas`
--

INSERT INTO `tugas` (`id`, `mata_kuliah_id`, `judul`, `deskripsi`, `tanggal_deadline`) VALUES
(1, 2, 'Membuat Aplikasi Sederhana', 'Membuat aplikasi sederhana menggunakan docker (atau yang lain), harus ada DB, web based. Menggunakan bahasa pemrograman bebas.', '2024-06-11'),
(2, 7, 'Pertemuan 2 - tugas1 HTML', 'Mengerjakan tugas HTML sesuai dengan instruksi pada pertemuan 2.', '2024-06-11'),
(3, 7, 'Pertemuan 6 - tugas CSS membuat tampilan web Unissula', 'Mengerjakan tugas CSS untuk membuat tampilan web Unissula sesuai dengan instruksi pada pertemuan 6.', '2024-06-11'),
(4, 7, 'Pertemuan 8 - tugas besar membuat aplikasi study planner', 'Mengerjakan tugas besar untuk membuat aplikasi study planner sesuai dengan instruksi pada pertemuan 8.', '2024-06-11'),
(5, 8, 'Presentasi Kelompok: Modul yang Telah Diberikan', 'Membahas modul yang telah diberikan dalam bentuk presentasi oleh kelompok.', '2024-06-11'),
(6, 9, 'Tugas Pertemuan 2: Modul OSI Layer dan Lapisan Fisik', 'Mengerjakan tugas sesuai dengan materi Modul OSI Layer dan Lapisan Fisik pada pertemuan 2.', '2024-06-11'),
(7, 9, 'Tugas Pertemuan 4: Lapisan Jaringan Part 1', 'Mengerjakan tugas sesuai dengan materi Lapisan Jaringan Part 1 pada pertemuan 4.', '2024-06-11'),
(8, 9, 'Tugas Pertemuan 10: Tugas Capture Protocol TCP', 'Mengerjakan tugas capture protocol TCP sesuai dengan materi pada pertemuan 10.', '2024-06-11');

-- --------------------------------------------------------

--
-- Table structure for table `tugas_proyek`
--

CREATE TABLE `tugas_proyek` (
  `id` int(11) NOT NULL,
  `proyek_id` int(11) DEFAULT NULL,
  `pengguna_id` int(11) DEFAULT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `tanggal_deadline` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tugas_proyek`
--

INSERT INTO `tugas_proyek` (`id`, `proyek_id`, `pengguna_id`, `judul`, `deskripsi`, `tanggal_deadline`) VALUES
(1, 1, 1, 'Tugas 1 HTML', 'Mengerjakan tugas HTML untuk pertemuan pertama.', '2024-03-23'),
(2, 1, 1, 'Tugas 2 CSS', 'Mengerjakan tugas CSS untuk pertemuan kedua.', '2024-04-28'),
(3, 1, 1, 'Latihan PHP', 'Mengerjakan latihan PHP.', '2024-05-26'),
(4, 1, 1, 'Latihan CRUD', 'Mengerjakan latihan CRUD dengan PHP.', '2024-05-31'),
(5, 1, 1, 'TUBES pemaparan laporan bab 1', 'Mempresentasikan laporan bab 1 untuk tugas besar (TUBES).', '2024-06-04'),
(6, 1, 1, 'TUBES pemaparan laporan bab 2', 'Mempresentasikan laporan bab 2 untuk tugas besar (TUBES).', '2024-06-11'),
(7, 1, 1, 'TUBES rancangan user interface', 'Membuat rancangan user interface untuk tugas besar (TUBES).', '2024-06-25'),
(8, 1, 1, 'TUBES mempresentasikan aplikasi student planner', 'Mempresentasikan aplikasi student planner.', '2024-07-02'),
(9, 1, 1, 'TUBES mempresentasikan aplikasi student planner (cont)', 'Mempresentasikan aplikasi student planner (lanjutan).', '2024-07-08');

-- --------------------------------------------------------

--
-- Table structure for table `ulang_mata_kuliah`
--

CREATE TABLE `ulang_mata_kuliah` (
  `id` int(11) NOT NULL,
  `pengguna_id` int(11) DEFAULT NULL,
  `mata_kuliah_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aktivitas_belajar`
--
ALTER TABLE `aktivitas_belajar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FOREIGN KEY` (`pengguna_id`,`mata_kuliah_id`,`tugas_id`);

--
-- Indexes for table `catatan`
--
ALTER TABLE `catatan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`);

--
-- Indexes for table `catatan_meeting`
--
ALTER TABLE `catatan_meeting`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`),
  ADD KEY `tugas_proyek_id` (`tugas_proyek_id`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengguna_id` (`pengguna_id`),
  ADD KEY `proyek_grup_id` (`proyek_grup_id`);

--
-- Indexes for table `jadwal_kuliah`
--
ALTER TABLE `jadwal_kuliah`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`);

--
-- Indexes for table `jadwal_meeting`
--
ALTER TABLE `jadwal_meeting`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tugas_proyek_id` (`tugas_proyek_id`);

--
-- Indexes for table `jadwal_ujian`
--
ALTER TABLE `jadwal_ujian`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`);

--
-- Indexes for table `kalender_kegiatan`
--
ALTER TABLE `kalender_kegiatan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengguna_id` (`pengguna_id`);

--
-- Indexes for table `kehadiran`
--
ALTER TABLE `kehadiran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengguna_id` (`pengguna_id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`);

--
-- Indexes for table `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  ADD PRIMARY KEY (`id`),
  ADD KEY `semester_id` (`semester_id`);

--
-- Indexes for table `materi`
--
ALTER TABLE `materi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`);

--
-- Indexes for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengguna_id` (`pengguna_id`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengguna_id` (`pengguna_id`),
  ADD KEY `fk_semester_id` (`semester_id`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `pengguna_mata_kuliah`
--
ALTER TABLE `pengguna_mata_kuliah`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengguna_id` (`pengguna_id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`);

--
-- Indexes for table `proyek_grup`
--
ALTER TABLE `proyek_grup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timer`
--
ALTER TABLE `timer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengguna_id` (`pengguna_id`),
  ADD KEY `aktivitas_belajar_id` (`aktivitas_belajar_id`),
  ADD KEY `tugas_id` (`tugas_id`);

--
-- Indexes for table `todolist`
--
ALTER TABLE `todolist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`),
  ADD KEY `proyek_id` (`proyek_id`);

--
-- Indexes for table `to_do_list_user`
--
ALTER TABLE `to_do_list_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`),
  ADD KEY `pengguna_id` (`pengguna_id`);

--
-- Indexes for table `tugas`
--
ALTER TABLE `tugas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`);

--
-- Indexes for table `tugas_proyek`
--
ALTER TABLE `tugas_proyek`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proyek_id` (`proyek_id`),
  ADD KEY `pengguna_id` (`pengguna_id`);

--
-- Indexes for table `ulang_mata_kuliah`
--
ALTER TABLE `ulang_mata_kuliah`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengguna_id` (`pengguna_id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`),
  ADD KEY `semester_id` (`semester_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aktivitas_belajar`
--
ALTER TABLE `aktivitas_belajar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catatan`
--
ALTER TABLE `catatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `catatan_meeting`
--
ALTER TABLE `catatan_meeting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jadwal_kuliah`
--
ALTER TABLE `jadwal_kuliah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jadwal_meeting`
--
ALTER TABLE `jadwal_meeting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jadwal_ujian`
--
ALTER TABLE `jadwal_ujian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kalender_kegiatan`
--
ALTER TABLE `kalender_kegiatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kehadiran`
--
ALTER TABLE `kehadiran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `materi`
--
ALTER TABLE `materi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `notifikasi`
--
ALTER TABLE `notifikasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pengguna_mata_kuliah`
--
ALTER TABLE `pengguna_mata_kuliah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `proyek_grup`
--
ALTER TABLE `proyek_grup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `timer`
--
ALTER TABLE `timer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `todolist`
--
ALTER TABLE `todolist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `to_do_list_user`
--
ALTER TABLE `to_do_list_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tugas`
--
ALTER TABLE `tugas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tugas_proyek`
--
ALTER TABLE `tugas_proyek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ulang_mata_kuliah`
--
ALTER TABLE `ulang_mata_kuliah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `catatan`
--
ALTER TABLE `catatan`
  ADD CONSTRAINT `catatan_ibfk_1` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`);

--
-- Constraints for table `catatan_meeting`
--
ALTER TABLE `catatan_meeting`
  ADD CONSTRAINT `catatan_meeting_ibfk_1` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`),
  ADD CONSTRAINT `catatan_meeting_ibfk_2` FOREIGN KEY (`tugas_proyek_id`) REFERENCES `tugas_proyek` (`id`);

--
-- Constraints for table `chat`
--
ALTER TABLE `chat`
  ADD CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`),
  ADD CONSTRAINT `chat_ibfk_2` FOREIGN KEY (`proyek_grup_id`) REFERENCES `proyek_grup` (`id`);

--
-- Constraints for table `jadwal_kuliah`
--
ALTER TABLE `jadwal_kuliah`
  ADD CONSTRAINT `jadwal_kuliah_ibfk_1` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`);

--
-- Constraints for table `jadwal_meeting`
--
ALTER TABLE `jadwal_meeting`
  ADD CONSTRAINT `fk_tugas_proyek_id` FOREIGN KEY (`tugas_proyek_id`) REFERENCES `tugas_proyek` (`id`);

--
-- Constraints for table `jadwal_ujian`
--
ALTER TABLE `jadwal_ujian`
  ADD CONSTRAINT `jadwal_ujian_ibfk_1` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`);

--
-- Constraints for table `kalender_kegiatan`
--
ALTER TABLE `kalender_kegiatan`
  ADD CONSTRAINT `kalender_kegiatan_ibfk_1` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`);

--
-- Constraints for table `kehadiran`
--
ALTER TABLE `kehadiran`
  ADD CONSTRAINT `kehadiran_ibfk_1` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`),
  ADD CONSTRAINT `kehadiran_ibfk_2` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`);

--
-- Constraints for table `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  ADD CONSTRAINT `mata_kuliah_ibfk_1` FOREIGN KEY (`semester_id`) REFERENCES `semester` (`id`);

--
-- Constraints for table `materi`
--
ALTER TABLE `materi`
  ADD CONSTRAINT `materi_ibfk_1` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`);

--
-- Constraints for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD CONSTRAINT `notifikasi_ibfk_1` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`);

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `fk_semester_id` FOREIGN KEY (`semester_id`) REFERENCES `semester` (`id`),
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`);

--
-- Constraints for table `pengguna_mata_kuliah`
--
ALTER TABLE `pengguna_mata_kuliah`
  ADD CONSTRAINT `pengguna_mata_kuliah_ibfk_1` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`),
  ADD CONSTRAINT `pengguna_mata_kuliah_ibfk_2` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`);

--
-- Constraints for table `proyek_grup`
--
ALTER TABLE `proyek_grup`
  ADD CONSTRAINT `proyek_grup_ibfk_1` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`);

--
-- Constraints for table `timer`
--
ALTER TABLE `timer`
  ADD CONSTRAINT `timer_ibfk_1` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`),
  ADD CONSTRAINT `timer_ibfk_2` FOREIGN KEY (`aktivitas_belajar_id`) REFERENCES `aktivitas_belajar` (`id`),
  ADD CONSTRAINT `timer_ibfk_3` FOREIGN KEY (`tugas_id`) REFERENCES `tugas` (`id`);

--
-- Constraints for table `todolist`
--
ALTER TABLE `todolist`
  ADD CONSTRAINT `todolist_ibfk_1` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`),
  ADD CONSTRAINT `todolist_ibfk_2` FOREIGN KEY (`proyek_id`) REFERENCES `proyek_grup` (`id`);

--
-- Constraints for table `to_do_list_user`
--
ALTER TABLE `to_do_list_user`
  ADD CONSTRAINT `to_do_list_user_ibfk_1` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`),
  ADD CONSTRAINT `to_do_list_user_ibfk_2` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`);

--
-- Constraints for table `tugas`
--
ALTER TABLE `tugas`
  ADD CONSTRAINT `tugas_ibfk_1` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`);

--
-- Constraints for table `tugas_proyek`
--
ALTER TABLE `tugas_proyek`
  ADD CONSTRAINT `tugas_proyek_ibfk_1` FOREIGN KEY (`proyek_id`) REFERENCES `proyek_grup` (`id`),
  ADD CONSTRAINT `tugas_proyek_ibfk_2` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`);

--
-- Constraints for table `ulang_mata_kuliah`
--
ALTER TABLE `ulang_mata_kuliah`
  ADD CONSTRAINT `ulang_mata_kuliah_ibfk_1` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`),
  ADD CONSTRAINT `ulang_mata_kuliah_ibfk_2` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`),
  ADD CONSTRAINT `ulang_mata_kuliah_ibfk_3` FOREIGN KEY (`semester_id`) REFERENCES `semester` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
